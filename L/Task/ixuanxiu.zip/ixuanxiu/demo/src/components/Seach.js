import React, { Component } from 'react'
import "../assets/style/search.css"
import { NavLink ,Link} from 'react-router-dom'
export default class Seach extends Component {
    render() {
        return (
            <div className="Searcher">
                <div className="Search_left">
                    {/* <div className="xuanke"><h1>选课</h1></div>
                    <div className="wo"><h1>我</h1></div> */}
                    <NavLink className="xuanke" to="/">选课</NavLink>
                    <NavLink  className="wo" to="/MyPage">我</NavLink>
                </div>
                <Link to="/SearchPage">
                    <div className="imgs"><img src={require('../assets/images/fangdajing.png')} alt=""/></div>
                </Link>
            </div>
        )
    }
}
