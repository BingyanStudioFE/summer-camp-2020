import React, { Component } from 'react'
import '../assets/style/header2.css'

export default class Header2 extends Component {
    // constructor(props){
    //     super(props);
    //     this.state={
    //         history:require("history").createHashHistory,
    //     };
    // }
    render() {

        return (
            <div className="header2">
             {/* <div className="goback"> */}
                <img src={require('../assets/images/zuo.png')} alt=""></img>
                    <span>爱选修</span>
             {/* </div> */}
            </div>
        )
    }
    // goback = () => {
    //     this.state.history().goBack();
    // }
}
