// 入口文件，在项目中，就像清单一样


// 引入核心组件
import "./pages/App"
// 引入插件
// import "./test/testbtn"

// 引入初始化样式
import "normalize.css"
// 引入全局样式
import "./assets/style/core.css"
















// import React from 'react';
// import ReactDOM from 'react-dom';
// // import './index.css';
// import App from './App';
// // import * as serviceWorker from './serviceWorker';

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // If you want your app to work offline and load faster, you can change
// // unregister() to register() below. Note this comes with some pitfalls.
// // Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();
